# LAB - Class 02

## Lab: Node Ecosystem, CI, CD

### Author: Mariko Alvarado

### Links and Resources
 - [ci/cd](https://github.com/Mariko-401-AdvancedJs/basic-express-server/actions)

 - [PR](https://github.com/Mariko-401-AdvancedJs/basic-express-server/pull/1)

 - [front-end application](https://mariko-express-server.herokuapp.com/)

### Setup

`.env` requirements

- `PORT` - 3000